import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Heart, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { roomTypes } from "@/lib/data";
import { motion } from "framer-motion";

export function MainNav() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on location change
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
      scrolled || isOpen ? "bg-white shadow-md py-2" : "bg-white/80 backdrop-blur-sm py-4"
    )}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-primary">
            InteriorVision
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link to="/">
              <Button variant={location.pathname === "/" ? "default" : "ghost"}>
                Home
              </Button>
            </Link>
            {roomTypes.slice(0, 4).map((room) => (
              <Link key={room.id} to={`/rooms/${room.id}`}>
                <Button variant={location.pathname === `/rooms/${room.id}` ? "default" : "ghost"}>
                  {room.icon} {room.name}
                </Button>
              </Link>
            ))}
            <Link to="/favorites">
              <Button variant={location.pathname === "/favorites" ? "default" : "ghost"}>
                <Heart className="mr-1 h-4 w-4" />
                Favorites
              </Button>
            </Link>
          </nav>
          
          {/* Mobile menu button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X /> : <Menu />}
          </Button>
        </div>
        
        {/* Mobile Navigation */}
        {isOpen && (
          <motion.div 
            className="md:hidden pt-4 pb-2"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
          >
            <nav className="flex flex-col space-y-2">
              <Link to="/">
                <Button 
                  variant={location.pathname === "/" ? "default" : "ghost"}
                  className="w-full justify-start"
                >
                  Home
                </Button>
              </Link>
              {roomTypes.map((room) => (
                <Link key={room.id} to={`/rooms/${room.id}`}>
                  <Button 
                    variant={location.pathname === `/rooms/${room.id}` ? "default" : "ghost"}
                    className="w-full justify-start"
                  >
                    <span className="mr-2">{room.icon}</span> {room.name}
                  </Button>
                </Link>
              ))}
              <Link to="/favorites">
                <Button 
                  variant={location.pathname === "/favorites" ? "default" : "ghost"}
                  className="w-full justify-start"
                >
                  <Heart className="mr-2 h-4 w-4" /> Favorites
                </Button>
              </Link>
            </nav>
          </motion.div>
        )}
      </div>
    </header>
  );
}