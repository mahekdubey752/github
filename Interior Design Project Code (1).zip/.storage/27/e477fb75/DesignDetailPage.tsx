import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MainNav } from "@/components/main-nav";
import { Footer } from "@/components/footer";
import { ColorPalette } from "@/components/color-palette";
import { roomDesigns } from "@/lib/data";
import { formatCurrency, isFavoriteDesign, toggleFavoriteDesign } from "@/lib/utils";
import { RoomDesign } from "@/types";
import { ArrowLeft, Heart, Share2, RotateCw } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DesignDetailPage() {
  const { designId } = useParams<{ designId: string }>();
  const navigate = useNavigate();
  const [design, setDesign] = useState<RoomDesign | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  useEffect(() => {
    if (designId) {
      setLoading(true);
      
      // Find the design
      const foundDesign = roomDesigns.find(d => d.id === designId);
      if (foundDesign) {
        setDesign(foundDesign);
        setIsFavorite(isFavoriteDesign(foundDesign.id));
      }
      
      setTimeout(() => {
        setLoading(false);
      }, 500);
    }
  }, [designId]);

  const handleFavoriteToggle = () => {
    if (design) {
      const newIsFavorite = toggleFavoriteDesign(design.id);
      setIsFavorite(newIsFavorite);
    }
  };

  // In a real app, we'd have multiple images per design
  // For demo, we'll simulate having different angles of the same room
  const getSimulatedImages = () => {
    if (!design) return [];
    return [
      design.image,
      design.image.replace('.jpg', '/images/roomangle1.jpg'), 
      design.image.replace('.jpg', '/images/roomview.jpg'),
      design.image.replace('.jpg', '/images/Detail.jpg')
    ];
  };

  const simulatedImages = getSimulatedImages();

  if (!design && !loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <MainNav />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-2">Design Not Found</h1>
            <p className="text-gray-500 mb-6">The design you requested doesn't exist or has been removed.</p>
            <Button onClick={() => window.history.back()}>Go Back</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <MainNav />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back button */}
          <Button
            variant="ghost"
            className="mb-4"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4 mr-2" /> Back
          </Button>
          
          {loading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : design && (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Images Section */}
                <div className="space-y-4">
                  <div className="aspect-[4/3] bg-gray-100 rounded-lg overflow-hidden">
                    <img 
                      src={simulatedImages[activeImageIndex] || design.image} 
                      alt={design.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-2">
                    {simulatedImages.map((image, index) => (
                      <button
                        key={index}
                        className={`w-24 h-24 flex-shrink-0 rounded-md overflow-hidden border-2 ${
                          activeImageIndex === index ? 'border-primary' : 'border-transparent'
                        }`}
                        onClick={() => setActiveImageIndex(index)}
                      >
                        <img 
                          src={image} 
                          alt={`${design.title} view ${index + 1}`} 
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Details Section */}
                <div>
                  <div className="flex justify-between items-start">
                    <h1 className="text-3xl font-bold">{design.title}</h1>
                    <Badge variant="outline" className="text-lg px-3 py-1">
                      {formatCurrency(design.price)}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center mt-2 mb-4">
                    <div className="flex mr-2">
                      {[...Array(5)].map((_, i) => (
                        <span 
                          key={i} 
                          className={`${i < Math.floor(design.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                        >
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-gray-600">({design.rating.toFixed(1)})</span>
                  </div>

                  <p className="text-gray-700 mb-6">
                    {design.description}
                  </p>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-2">Room Type</h3>
                    <Badge variant="secondary" className="text-base px-3 py-1">
                      {design.roomType.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                    </Badge>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-2">Color Palette</h3>
                    <ColorPalette colors={design.colors} size="lg" />
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-2">Features</h3>
                    <div className="flex flex-wrap gap-2">
                      {design.features.map((feature, index) => (
                        <Badge key={index} variant="outline">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    <Button 
                      size="lg" 
                      onClick={handleFavoriteToggle}
                      variant={isFavorite ? "default" : "outline"}
                    >
                      <Heart className={`mr-2 h-5 w-5 ${isFavorite ? "fill-current" : ""}`} />
                      {isFavorite ? "Saved to Favorites" : "Save to Favorites"}
                    </Button>
                    
                    <Button size="lg" variant="outline">
                      <Share2 className="mr-2 h-5 w-5" />
                      Share Design
                    </Button>
                    
                    <Button size="lg" variant="outline">
                      <RotateCw className="mr-2 h-5 w-5" />
                      View in 3D
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Additional Information Tabs */}
              <Tabs defaultValue="description" className="mt-12">
                <TabsList className="grid grid-cols-3 w-full max-w-md">
                  <TabsTrigger value="description">Description</TabsTrigger>
                  <TabsTrigger value="materials">Materials</TabsTrigger>
                  <TabsTrigger value="dimensions">Dimensions</TabsTrigger>
                </TabsList>
                <TabsContent value="description" className="mt-4">
                  <div className="bg-white p-6 rounded-lg shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">Design Details</h3>
                    <p className="mb-4">
                      {design.description}
                    </p>
                    <p className="mb-4">
                      This {design.roomType.split('-').join(' ')} design combines functionality with aesthetic appeal, 
                      creating a space that is both practical and visually stunning. The careful selection of colors,
                      materials, and layout ensures a balanced environment that meets the needs of modern living.
                    </p>
                    <p>
                      The design can be customized to fit your specific space dimensions and personal preferences,
                      while maintaining the core design principles that make it successful.
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="materials" className="mt-4">
                  <div className="bg-white p-6 rounded-lg shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">Materials Used</h3>
                    <ul className="list-disc list-inside space-y-2">
                      <li>Premium quality engineered wood for furniture pieces</li>
                      <li>High-grade fabrics for upholstery with stain-resistant treatment</li>
                      <li>Eco-friendly paint options for walls</li>
                      <li>Energy-efficient LED lighting fixtures</li>
                      <li>Sustainable bamboo or reclaimed wood accents</li>
                      <li>Durable hardware with contemporary finishes</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <TabsContent value="dimensions" className="mt-4">
                  <div className="bg-white p-6 rounded-lg shadow-sm">
                    <h3 className="text-xl font-semibold mb-4">Room Dimensions</h3>
                    <p className="mb-4">This design is optimized for the following dimensions:</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-semibold mb-2">Standard Configuration</h4>
                        <ul className="space-y-1 text-sm">
                          <li>Room Width: 12-15 feet (3.7-4.6 meters)</li>
                          <li>Room Length: 15-18 feet (4.6-5.5 meters)</li>
                          <li>Ceiling Height: 8-10 feet (2.4-3.0 meters)</li>
                        </ul>
                      </div>
                      
                      <div className="border rounded-md p-4">
                        <h4 className="font-semibold mb-2">Compact Configuration</h4>
                        <ul className="space-y-1 text-sm">
                          <li>Room Width: 10-12 feet (3.0-3.7 meters)</li>
                          <li>Room Length: 12-15 feet (3.7-4.6 meters)</li>
                          <li>Ceiling Height: 8 feet (2.4 meters)</li>
                        </ul>
                      </div>
                    </div>
                    
                    <p className="mt-4 text-sm text-gray-600">
                      * Design can be scaled and adapted to fit your specific room dimensions
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
              
              {/* Similar Designs */}
              <div className="mt-16">
                <h2 className="text-2xl font-bold mb-6">Similar Designs You Might Like</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {roomDesigns
                    .filter(d => d.roomType === design.roomType && d.id !== design.id)
                    .slice(0, 3)
                    .map(similarDesign => (
                      <RoomCard key={similarDesign.id} design={similarDesign} />
                    ))
                  }
                </div>
              </div>
            </>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}