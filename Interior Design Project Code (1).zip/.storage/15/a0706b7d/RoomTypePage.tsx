import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MainNav } from "@/components/main-nav";
import { Footer } from "@/components/footer";
import { RoomCard } from "@/components/room-card";
import { RoomFilter, FilterState } from "@/components/room-filter";
import { roomTypes, roomDesigns } from "@/lib/data";
import { RoomType as RoomTypeInterface, RoomDesign } from "@/types";
import { Loader2 } from "lucide-react";

export default function RoomTypePage() {
  const { roomTypeId } = useParams<{ roomTypeId: string }>();
  const [designs, setDesigns] = useState<RoomDesign[]>([]);
  const [filteredDesigns, setFilteredDesigns] = useState<RoomDesign[]>([]);
  const [loading, setLoading] = useState(true);
  const [roomType, setRoomType] = useState<{ name: string; description: string; icon: string } | null>(null);

  useEffect(() => {
    if (roomTypeId) {
      setLoading(true);
      // Find room type data
      const currentRoomType = roomTypes.find(room => room.id === roomTypeId);
      if (currentRoomType) {
        setRoomType(currentRoomType);
      }

      // Get designs for this room type
      const roomTypeDesigns = roomDesigns.filter(design => design.roomType === roomTypeId);
      setDesigns(roomTypeDesigns);
      setFilteredDesigns(roomTypeDesigns);
      
      // Simulate loading state for better UX
      setTimeout(() => {
        setLoading(false);
      }, 500);
    }
  }, [roomTypeId]);

  const handleFilterChange = (filters: FilterState) => {
    const { priceRange, selectedColors, selectedStyles } = filters;
    
    const filtered = designs.filter(design => {
      // Price filter
      if (design.price < priceRange[0] || design.price > priceRange[1]) {
        return false;
      }
      
      // Color scheme filter (if any selected)
      // This is simplified - in a real app, you'd have a more robust color matching system
      if (selectedColors.length > 0) {
        // Assume each design has a dominant color scheme ID
        // Here we're just randomly checking if there's overlap between selected colors and design colors
        // In a real app, you'd have proper color scheme IDs for each design
        const hasMatchingColor = selectedColors.some((colorId) => {
          return design.colors.some(color => color.includes(colorId));
        });
        
        if (!hasMatchingColor) return false;
      }
      
      // Style filter (if any selected)
      // Similar to colors, in a real app you'd have actual style data for each design
      if (selectedStyles.length > 0) {
        // Simple random matching for demo purposes
        const designStyleIndex = design.id.charCodeAt(0) % designStyles.length;
        const designStyle = designStyles[designStyleIndex];
        if (!selectedStyles.includes(designStyle)) return false;
      }
      
      return true;
    });
    
    setFilteredDesigns(filtered);
  };
  
  // For demo purposes only
  const designStyles = ['modern', 'traditional', 'scandinavian', 'industrial', 'bohemian'];

  if (!roomType && !loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <MainNav />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-2">Room Type Not Found</h1>
            <p className="text-gray-500 mb-6">The room type you requested doesn't exist.</p>
            <Button onClick={() => window.history.back()}>Go Back</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <MainNav />
      
      <main className="flex-grow pt-24">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-50 to-indigo-50 py-12">
          <div className="container mx-auto px-4">
            {loading ? (
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                <p>Loading room designs...</p>
              </div>
            ) : (
              <>
                <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center">
                  {roomType?.icon && <span className="mr-2">{roomType.icon}</span>}
                  {roomType?.name} Designs
                </h1>
                <p className="text-gray-600 max-w-2xl">
                  {roomType?.description}
                </p>
              </>
            )}
          </div>
        </section>
        
        <section className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Filters Sidebar */}
            <aside className="w-full md:w-1/4">
              <RoomFilter 
                selectedRoomType={roomTypeId as RoomTypeInterface} 
                onFilterChange={handleFilterChange} 
              />
            </aside>
            
            {/* Room Designs Grid */}
            <div className="w-full md:w-3/4">
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : filteredDesigns.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredDesigns.map(design => (
                    <RoomCard key={design.id} design={design} />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 rounded-lg p-8 text-center">
                  <h3 className="text-xl font-semibold mb-2">No designs found</h3>
                  <p className="text-gray-500 mb-4">
                    Try adjusting your filters to find more designs
                  </p>
                  <Button onClick={() => {
                    // Reset filters
                    setFilteredDesigns(designs);
                  }}>
                    Clear Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}