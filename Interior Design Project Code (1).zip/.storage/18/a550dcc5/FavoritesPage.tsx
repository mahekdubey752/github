import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MainNav } from "@/components/main-nav";
import { Footer } from "@/components/footer";
import { RoomCard } from "@/components/room-card";
import { roomDesigns } from "@/lib/data";
import { getFavoriteDesigns } from "@/lib/utils";
import { RoomDesign } from "@/types";
import { Heart, ArrowRight } from "lucide-react";

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<RoomDesign[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get favorite designs
    setLoading(true);
    const favoriteDesigns = getFavoriteDesigns(roomDesigns);
    setFavorites(favoriteDesigns);
    
    setTimeout(() => {
      setLoading(false);
    }, 500);
  }, []);

  const handleFavoriteToggle = (designId: string, isFavorited: boolean) => {
    if (!isFavorited) {
      // Remove from favorites if unfavorited
      setFavorites(favorites.filter(design => design.id !== designId));
    }
  };

  // Group favorites by room type
  const favoritesByType = favorites.reduce((acc: Record<string, RoomDesign[]>, design) => {
    if (!acc[design.roomType]) {
      acc[design.roomType] = [];
    }
    acc[design.roomType].push(design);
    return acc;
  }, {});

  return (
    <div className="min-h-screen flex flex-col">
      <MainNav />
      
      <main className="flex-grow pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold flex items-center">
              <Heart className="h-8 w-8 mr-2 text-primary" /> My Favorites
            </h1>
          </div>

          {loading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : favorites.length > 0 ? (
            <div className="space-y-16">
              {Object.entries(favoritesByType).map(([roomType, designs]) => (
                <div key={roomType}>
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-semibold capitalize">
                      {roomType.split('-').join(' ')} Designs
                    </h2>
                    <Link to={`/rooms/${roomType}`}>
                      <Button variant="ghost">
                        View All <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {designs.map(design => (
                      <RoomCard 
                        key={design.id} 
                        design={design}
                        onFavoriteToggle={handleFavoriteToggle}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-12 text-center">
              <div className="w-16 h-16 rounded-full bg-gray-100 mx-auto mb-4 flex items-center justify-center">
                <Heart className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold mb-2">No Favorites Yet</h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">
                You haven't saved any designs to your favorites yet. Explore our collections and save designs you love.
              </p>
              <Link to="/">
                <Button size="lg">
                  Explore Designs
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}