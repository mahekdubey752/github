export interface RoomDesign {
  id: string;
  title: string;
  description: string;
  image: string;
  roomType: RoomType;
  features: string[];
  colors: string[];
  price: number;
  rating: number;
}

export type RoomType = 'bedroom' | 'living-room' | 'kitchen' | 'bathroom' | 'office' | 'dining-room';

export interface UserPreferences {
  favoriteDesigns: string[];
  colorPreferences: string[];
  stylePreferences: string[];
}