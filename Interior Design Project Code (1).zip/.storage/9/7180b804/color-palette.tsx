import { cn } from "@/lib/utils";

interface ColorPaletteProps {
  colors: string[];
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: (color: string) => void;
}

export function ColorPalette({ colors, size = 'md', className, onClick }: ColorPaletteProps) {
  const sizeClasses = {
    sm: 'h-3 w-3',
    md: 'h-5 w-5',
    lg: 'h-8 w-8'
  };

  return (
    <div className={cn("flex gap-1", className)}>
      {colors.map((color, index) => (
        <div 
          key={index}
          className={cn(
            sizeClasses[size], 
            "rounded-full border shadow-sm transition-transform", 
            onClick ? "cursor-pointer hover:scale-110" : ""
          )}
          style={{ backgroundColor: color }}
          onClick={() => onClick && onClick(color)}
          title={color}
        />
      ))}
    </div>
  );
}