import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { RoomCard } from "@/components/room-card";
import { MainNav } from "@/components/main-nav";
import { Footer } from "@/components/footer";
import { roomTypes, roomDesigns } from "@/lib/data";
import { ArrowRight, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  // Get a sampling of designs for each room type (up to 3 per type)
  const getTypeDesigns = (type: string) => {
    return roomDesigns
      .filter(design => design.roomType === type)
      .slice(0, 3);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <MainNav />
      
      {/* Hero Section */}
      <section className="pt-28 pb-16 md:pt-36 md:pb-24 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="w-full md:w-1/2 mb-8 md:mb-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Transform Your Space With Stunning Interior Designs
              </h1>
              <p className="text-xl text-gray-600 mb-6">
                Discover beautiful and functional designs for every room in your home.
                From minimalist bedrooms to luxury kitchens, find your perfect style.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/rooms/bedroom">
                  <Button size="lg" className="rounded-full">
                    Explore Bedroom Designs
                  </Button>
                </Link>
                <Link to="/rooms/kitchen">
                  <Button size="lg" variant="outline" className="rounded-full">
                    View Kitchen Designs
                  </Button>
                </Link>
              </div>
            </motion.div>
            <motion.div 
              className="w-full md:w-1/2 relative"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <img
                src="/assets/rooms/hero-image.jpg"
                alt="Beautiful interior design"
                className="rounded-xl shadow-2xl object-cover"
                style={{ aspectRatio: "4/3" }}
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg hidden md:block">
                <div className="flex items-center gap-2">
                  <div className="bg-primary rounded-full p-1">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm font-medium">Professional Designs</span>
                </div>
              </div>
              <div className="absolute -top-6 -right-6 bg-white p-4 rounded-lg shadow-lg hidden md:block">
                <div className="flex items-center gap-2">
                  <div className="bg-primary rounded-full p-1">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-sm font-medium">Customizable Solutions</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Room Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2 text-center">Explore By Room</h2>
          <p className="text-gray-500 mb-8 text-center max-w-2xl mx-auto">
            Find inspiration for every space in your home with our curated collections
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {roomTypes.map((room) => (
              <Link 
                key={room.id} 
                to={`/rooms/${room.id}`}
                className="group block"
              >
                <div className="bg-gray-100 p-6 rounded-xl text-center hover:bg-primary/10 transition-colors group-hover:shadow-md">
                  <div className="text-4xl mb-2">{room.icon}</div>
                  <h3 className="font-medium">{room.name}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Designs */}
      {roomTypes.slice(0, 3).map((roomType) => (
        <section key={roomType.id} className="py-16 bg-gray-50 even:bg-white">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold">{roomType.name} Designs</h2>
                <p className="text-gray-500">{roomType.description}</p>
              </div>
              <Link to={`/rooms/${roomType.id}`}>
                <Button variant="ghost">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {getTypeDesigns(roomType.id).map((design) => (
                <RoomCard key={design.id} design={design} />
              ))}
            </div>
          </div>
        </section>
      ))}

      {/* Why Choose Us */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Why Choose InteriorVision</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/10 p-6 rounded-xl backdrop-blur-sm">
              <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Professionally Designed</h3>
              <p className="text-white/80">
                All our designs are created by professional interior designers with years of experience.
              </p>
            </div>

            <div className="bg-white/10 p-6 rounded-xl backdrop-blur-sm">
              <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Time Saving</h3>
              <p className="text-white/80">
                Save hours of planning and designing by using our ready-made, customizable designs.
              </p>
            </div>

            <div className="bg-white/10 p-6 rounded-xl backdrop-blur-sm">
              <div className="bg-white/20 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Guaranteed</h3>
              <p className="text-white/80">
                Every design is carefully crafted with attention to detail and aesthetic appeal.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-r from-blue-100 to-indigo-100 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h2 className="text-3xl font-bold mb-2">Ready to Transform Your Space?</h2>
              <p className="text-gray-700 mb-4">
                Explore our extensive collection of designs or save your favorites to create your dream interior.
              </p>
              <Link to="/rooms/bedroom">
                <Button size="lg" className="rounded-full">
                  Get Started Now
                </Button>
              </Link>
            </div>
            <div className="md:w-1/3 md:text-right">
              <img src="/assets/rooms/cta-image.jpg" alt="Interior Design" className="rounded-xl" />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}