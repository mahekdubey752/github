import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { colorSchemes, designStyles } from "@/lib/data";
import { ColorPalette } from "@/components/color-palette";
import { RoomType } from "@/types";
import { cn } from "@/lib/utils";

interface RoomFilterProps {
  selectedRoomType: RoomType | null;
  onFilterChange: (filters: FilterState) => void;
}

export interface FilterState {
  priceRange: [number, number];
  selectedColors: string[];
  selectedStyles: string[];
  selectedRoomType: RoomType | null;
}

export function RoomFilter({ selectedRoomType, onFilterChange }: RoomFilterProps) {
  const [filters, setFilters] = useState<FilterState>({
    priceRange: [0, 30000],
    selectedColors: [],
    selectedStyles: [],
    selectedRoomType
  });

  const handlePriceChange = (value: number[]) => {
    const newFilters = {
      ...filters,
      priceRange: [value[0], value[1]] as [number, number]
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const toggleColor = (colorId: string) => {
    const newSelectedColors = filters.selectedColors.includes(colorId)
      ? filters.selectedColors.filter(id => id !== colorId)
      : [...filters.selectedColors, colorId];
    
    const newFilters = {
      ...filters,
      selectedColors: newSelectedColors
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const toggleStyle = (styleId: string) => {
    const newSelectedStyles = filters.selectedStyles.includes(styleId)
      ? filters.selectedStyles.filter(id => id !== styleId)
      : [...filters.selectedStyles, styleId];
    
    const newFilters = {
      ...filters,
      selectedStyles: newSelectedStyles
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const resetFilters = () => {
    const newFilters = {
      priceRange: [0, 30000],
      selectedColors: [],
      selectedStyles: [],
      selectedRoomType
    };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="p-4 space-y-6 bg-white rounded-lg shadow">
      <div>
        <h3 className="text-lg font-medium mb-2">Price Range</h3>
        <div className="px-2">
          <Slider 
            defaultValue={filters.priceRange} 
            min={0} 
            max={30000} 
            step={1000}
            onValueChange={handlePriceChange}
          />
          <div className="flex justify-between mt-2 text-sm text-muted-foreground">
            <span>${filters.priceRange[0].toLocaleString()}</span>
            <span>${filters.priceRange[1].toLocaleString()}</span>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium mb-2">Color Schemes</h3>
        <div className="flex flex-wrap gap-3">
          {colorSchemes.map((scheme) => (
            <div 
              key={scheme.id}
              className={cn(
                "flex items-center p-2 rounded-md border cursor-pointer transition-all",
                filters.selectedColors.includes(scheme.id) 
                  ? "border-primary bg-primary/10" 
                  : "border-gray-200 hover:border-gray-300"
              )}
              onClick={() => toggleColor(scheme.id)}
            >
              <span className="text-sm mr-2">{scheme.name}</span>
              <ColorPalette colors={scheme.colors} size="sm" />
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-2">Design Styles</h3>
        <div className="flex flex-wrap gap-2">
          {designStyles.map((style) => (
            <Badge 
              key={style.id}
              variant={filters.selectedStyles.includes(style.id) ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => toggleStyle(style.id)}
            >
              {style.name}
            </Badge>
          ))}
        </div>
      </div>

      <Button onClick={resetFilters} variant="outline" className="w-full">
        Reset Filters
      </Button>
    </div>
  );
}