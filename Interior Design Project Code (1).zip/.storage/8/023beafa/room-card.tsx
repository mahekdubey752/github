import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart } from "lucide-react";
import { RoomDesign } from "@/types";
import { formatCurrency, isFavoriteDesign, toggleFavoriteDesign } from "@/lib/utils";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

interface RoomCardProps {
  design: RoomDesign;
  onFavoriteToggle?: (designId: string, isFavorited: boolean) => void;
}

export function RoomCard({ design, onFavoriteToggle }: RoomCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check if this design is favorited
    setIsFavorite(isFavoriteDesign(design.id));
  }, [design.id]);

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const newIsFavorite = toggleFavoriteDesign(design.id);
    setIsFavorite(newIsFavorite);
    if (onFavoriteToggle) {
      onFavoriteToggle(design.id, newIsFavorite);
    }
  };

  const handleClick = () => {
    navigate(`/design/${design.id}`);
  };

  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg cursor-pointer" onClick={handleClick}>
      <div className="relative overflow-hidden aspect-[4/3]">
        <img 
          src={design.image} 
          alt={design.title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <Button 
          variant="ghost" 
          size="icon"
          className={`absolute top-2 right-2 rounded-full bg-white/80 hover:bg-white ${isFavorite ? 'text-red-500' : 'text-gray-500'}`}
          onClick={handleFavoriteToggle}
        >
          <Heart className={isFavorite ? "fill-current" : ""} />
        </Button>
      </div>
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{design.title}</CardTitle>
          <Badge variant="outline">{formatCurrency(design.price)}</Badge>
        </div>
        <CardDescription className="line-clamp-2">{design.description}</CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="flex flex-wrap gap-1">
          {design.features.slice(0, 2).map((feature, index) => (
            <Badge variant="secondary" key={index} className="text-xs">
              {feature}
            </Badge>
          ))}
          {design.features.length > 2 && (
            <Badge variant="secondary" className="text-xs">
              +{design.features.length - 2} more
            </Badge>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between">
        <div className="flex items-center">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={`text-sm ${i < Math.floor(design.rating) ? 'text-yellow-400' : 'text-gray-300'}`}>★</span>
            ))}
          </div>
          <span className="text-sm text-muted-foreground ml-1">{design.rating.toFixed(1)}</span>
        </div>
      </CardFooter>
    </Card>
  );
}