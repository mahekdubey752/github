import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { RoomDesign, UserPreferences } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(amount);
}

// LocalStorage utility functions
export function saveToLocalStorage<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}

export function getFromLocalStorage<T>(key: string, defaultValue: T): T {
  const stored = localStorage.getItem(key);
  return stored ? JSON.parse(stored) as T : defaultValue;
}

// User preferences management
export function getUserPreferences(): UserPreferences {
  return getFromLocalStorage<UserPreferences>('userPreferences', {
    favoriteDesigns: [],
    colorPreferences: [],
    stylePreferences: [],
  });
}

export function toggleFavoriteDesign(designId: string): boolean {
  const preferences = getUserPreferences();
  const isFavorited = preferences.favoriteDesigns.includes(designId);
  
  if (isFavorited) {
    preferences.favoriteDesigns = preferences.favoriteDesigns.filter(id => id !== designId);
  } else {
    preferences.favoriteDesigns.push(designId);
  }
  
  saveToLocalStorage('userPreferences', preferences);
  return !isFavorited;
}

export function isFavoriteDesign(designId: string): boolean {
  const preferences = getUserPreferences();
  return preferences.favoriteDesigns.includes(designId);
}

export function getFavoriteDesigns(designs: RoomDesign[]): RoomDesign[] {
  const preferences = getUserPreferences();
  return designs.filter(design => preferences.favoriteDesigns.includes(design.id));
}